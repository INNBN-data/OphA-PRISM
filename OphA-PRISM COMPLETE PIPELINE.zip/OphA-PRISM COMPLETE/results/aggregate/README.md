# results/aggregate

See the repository README for this component.
