# Study metadata — author-reported

Development operations: 1 January 1998–18 July 2025, 261 adults. Reserved same-center operations: 1 January–31 March 2026, 28 adults. Development eras: 82 / 94 / 85 patients. Positive targets VISION / ACCESS / CONTROL / RECON / CURE: 23 / 84 / 62 / 165 / 50.

Registry scope is reported as 408 variables; the public bundle contains 142 candidate predictors, not a complete master dictionary. The latest availability table has 48 T0, 30 T1 and 64 T2 rows. VISION has 23 events and substantial outcome-ascertainment limitations. Models remain developmental. Ethics Project 6369 is reported dated 8 July 2026; standing authorization and dated analytical milestones are described in chronology_and_accrual_ledger.md.

Historical model identifier: v1.2.0. Newly revised reference software: 1.1.0, 23 October 2026. These identifiers refer to different objects.
