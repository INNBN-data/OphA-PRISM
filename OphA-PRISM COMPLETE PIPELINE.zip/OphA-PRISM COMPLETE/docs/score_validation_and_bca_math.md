# Score validation and interval estimands

## Integer representations

The supplied VISION and CURE point architectures have maxima 31 and 33. Original supplied surrogate coefficients and scaling are retained in `outputs/int_score_derivation.csv`; later author-reported probability mappings differ and are not substituted for validated calibration.

Five outer folds repeated ten times produce 50 fits. Each patient is held out in ten fits and belongs to training in the other forty. Validation must calculate that patient's score using only its ten corresponding training-only derivations. A pooled coefficient vector or full-data intercept/slope is a final development representation, not an independently held-out probability mapping. Average held-out probabilities for probability evaluation; specify score aggregation separately when calculating AUC. Fold-specific feature/bins/penalties and coefficients must be saved.

The author reports score AUCs VISION 0.788 (0.652–0.901) and CURE 0.876 (0.801–0.941). Underlying score predictions, coefficients and interval draws were not included. The module calculates supplied points, not a retrospective proof of their derivation. Score totals are not treatment thresholds.

## BCa intervals

For any target statistic theta, BCa requires its observed estimate, bootstrap estimates of that same statistic, and patient-level jackknife or otherwise justified influence values for that statistic. The mathematical BCa utility in `ophaprism/bca.py` accepts these vectors explicitly and performs no model fitting.

Optimism correction uses O_b = AUC_boot,b − AUC_orig,b, theta_corrected = AUC_apparent − mean(O_b). Those optimism values alone do not define bootstrap realizations of the entire corrected-performance estimator. A BCa interval for corrected AUC additionally requires a specified resampling procedure for corrected estimates, and influence calculations targeting that estimator. Nested resampling or another justified method must be documented.

The latest author description identifies corrected AUC as the target but does not supply the corrected-estimate and jackknife vectors. Consequently the reported BCa endpoints remain author-reported. The reference optimism command does not silently relabel quantiles of optimism as corrected-AUC confidence intervals.

References: https://stat.ethz.ch/R-manual/R-devel/library/boot/html/boot.ci.html and https://stat.ethz.ch/R-manual/R-devel/library/boot/html/empinf.html.
