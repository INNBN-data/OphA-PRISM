# Author-reported study chronology

| Date / period | Reported event |
| --- | --- |
| 1 January 1998–18 July 2025 | 261 development operations |
| 15 October 2025 | Internal analytical protocol |
| 15 January 2026 | Anatomical remeasurement completed |
| 20 January 2026 | Development dataset freeze |
| 1 January–31 March 2026 | 28 reserved operations; author reports 31 referrals, two endovascular and one observed |
| 15 February 2026 | Historical model v1.2.0 lock |
| 1 March / 15 March 2026 | Previously reported reserved-predictor / early-outcome analyst access |
| 8 July 2026 | Final ethics approval, Project 6369 |
| 15 October 2026 | Final six-month reserved-cohort evaluation |

The authors identify standing authorization INNBN-REG-2018-04 as covering earlier registry research and model development. Its signed scope, amendment history, actual screening records, dated freeze hashes, and historical lock objects were not supplied in this ZIP. These entries are reported chronology, not independently authenticated administrative records.

The authors attribute higher 2026 capture to a dedicated registry coordinator. This explanation and the 31→28 screening arithmetic do not independently establish surgical case volume. The reserved assessment is same-center temporal evaluation; some operations preceded the model lock. It is not independent institutional external validation.
