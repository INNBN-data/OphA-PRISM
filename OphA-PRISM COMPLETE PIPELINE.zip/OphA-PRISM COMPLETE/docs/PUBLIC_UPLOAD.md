# Uploading the revised source tree

Extract the ZIP and use the contents of its OphA-PRISM folder as the repository root. Preserve the directory hierarchy. Run `python run_pipeline.py check` and `python code/verify_aggregate_bundle.py` before uploading. This task creates an archive; it does not push commits or create a GitHub release.

Only allowlisted public metadata, aggregate files, code and documentation are packaged. Controlled clinical files and generated models remain excluded.
