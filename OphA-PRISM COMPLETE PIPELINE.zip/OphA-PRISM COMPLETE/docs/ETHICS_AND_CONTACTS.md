# Author-reported ethics, funding and interests

The authors report approval by the Ethics Committee of the National Institute of Neurological Disorders and Neurovascular Disease, Research Project 6369, 8 July 2026, and a waiver of individual consent for de-identified retrospective analysis. Standing authorization INNBN-REG-2018-04 is reported for earlier registry work. Signed authorizations were not included for inspection; institutional naming should follow those documents.

Authors: Matei Șerban; Corneliu Toader; Alexandru Vlad Ciurea; Leon Dănăilă; Răzvan-Adrian Covache-Busuioc. Correspondence: c.toader@innbn.ro and a.ciurea@innbn.ro.

The authors state that Puls Med Association supported study resources and publication and that association members conducted the work. 

The original software license is retained. Adding this documentation does not change that license or establish exclusive rights to scientific findings.
