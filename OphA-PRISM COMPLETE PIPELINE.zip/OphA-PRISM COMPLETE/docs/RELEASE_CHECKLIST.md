# Release checklist

- [x] Original hierarchy recovered and source recovery documented.
- [x] Updated reference software, configuration, license and citation included.
- [x] Latest 142-row availability data and aggregate additions integrated.
- [x] Numerical arithmetic checks pass; independent clinical verification is not implied.
- [x] Engineering checks and installed learner interfaces tested locally.
- [x] Explicit release allowlist, SHA-256 manifest and ZIP CRC checks used.
- [x] Missing historical records are identified without substitute observations.

Historical clinical reproduction remains unverified: source datasets, full registry dictionary, original fitting objects, complete resampling/SHAP records, date/authorization evidence and original R outputs are not supplied. These are separate from this completed software/package revision.
