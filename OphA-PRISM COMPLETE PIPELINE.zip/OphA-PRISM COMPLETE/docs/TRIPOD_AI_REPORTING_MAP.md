# Reporting checklist

See [the 27-item mapping](TRIPOD_AI_2024_checklist.md), including explicit partial/unavailable items.
