# PROBAST+AI structured assessment — provisional

Correct official item numbering is retained below; labels are concise paraphrases, not a verbatim reproduction of the instrument. This is a structured appraisal of the reported historical study, not independent source-data certification. It must be interpreted separately for VISION, ACCESS, CONTROL, RECON and CURE; the shared descriptions apply only where their measurement procedures coincide.

Source: Moons et al., BMJ 2025;388:e082505, https://doi.org/10.1136/bmj-2024-082505 and https://www.probast.org/probast_ai/downloads/.

## Development quality — 16 items

| Item | Paraphrased topic | Response | Rationale |
| --- | --- | --- | --- |
| 1.1 | Registry source suitability | Probably yes | The authors describe an institutional clinical registry; source records were not supplied. |
| 1.2 | Design suitability | Probably yes | Retrospective consecutive surgical development is described; temporal selection remains relevant. |
| 1.3 | Selection representativeness | No information | Exclusions and rapid reserved-cohort accrual need source-level reconciliation. |
| 2.1 | Uniform predictor ascertainment | Probably no | Acquisition resolution and examination availability changed materially across eras. |
| 2.2 | Uniform transformations | No information | Reference transformations are inspectable; historical preprocessing objects are absent. |
| 2.3 | Blinded predictor abstraction | Probably yes | Imaging-reader masking is author-reported. |
| 2.4 | Pre-incision availability | Probably yes | T0–T2 eligibility is specified; the exact historical predictor matrix remains unavailable. |
| 3.1 | Endpoint ascertainment quality | Probably no | VISION ascertainment is heterogeneous; operative phenotypes reflect practice choices. |
| 3.2 | Uniform endpoint ascertainment | Probably no | Formal paired visual assessment was incomplete and historical documentation varied. |
| 3.3 | Outcome-reader masking | Probably yes | Clinical/angiographic masking is reported, without the underlying adjudication forms. |
| 3.4 | Relevant assessment interval | Probably yes | Defined windows and six-month confirmation are reported; dates require source confirmation. |
| 4.1 | Adequate estimation support | No | Limited events and candidate search; the restricted CURE scenario reports a requirement of 309. |
| 4.2 | Predictor scale coding | No information | Complete categorical maps, derived-volume definition and historical transformations are missing. |
| 4.3 | Incomplete-record treatment | No information | Availability totals reconcile; biological applicability and historical MICE objects are not established. |
| 4.4 | Recalibration after weighting | No information | Weighting and calibration are described, but original fitted probability mappings are unavailable. |
| 4.5 | Overfitting safeguards | Probably yes | Penalization, selection and resampling are reported; these do not establish sample adequacy. |

## Evaluation risk of bias — 18 items

| Item | Paraphrased topic | Response | Rationale |
| --- | --- | --- | --- |
| 1.1 | Registry source suitability | Probably yes | The authors describe an institutional clinical registry; source records were not supplied. |
| 1.2 | Design suitability | Probably yes | Retrospective consecutive surgical development is described; temporal selection remains relevant. |
| 1.3 | Selection representativeness | No information | Exclusions and rapid reserved-cohort accrual need source-level reconciliation. |
| 2.1 | Uniform predictor ascertainment | Probably no | Acquisition resolution and examination availability changed materially across eras. |
| 2.2 | Uniform transformations | No information | Reference transformations are inspectable; historical preprocessing objects are absent. |
| 2.3 | Blinded predictor abstraction | Probably yes | Imaging-reader masking is author-reported. |
| 2.4 | Pre-incision availability | Probably yes | T0–T2 eligibility is specified; the exact historical predictor matrix remains unavailable. |
| 3.1 | Endpoint ascertainment quality | Probably no | VISION ascertainment is heterogeneous; operative phenotypes reflect practice choices. |
| 3.2 | Uniform endpoint ascertainment | Probably no | Formal paired visual assessment was incomplete and historical documentation varied. |
| 3.3 | Outcome-reader masking | Probably yes | Clinical/angiographic masking is reported, without the underlying adjudication forms. |
| 3.4 | Relevant assessment interval | Probably yes | Defined windows and six-month confirmation are reported; dates require source confirmation. |
| 4.1 | Beyond apparent evaluation | Yes | Nested and temporal performance are reported. |
| 4.2 | Evaluation sample precision | No | VISION has 23 development events; the reserved cohort has two VISION and five CURE events. |
| 4.3 | Incomplete-record treatment | No information | The original per-patient availability and outcome adjudication are unavailable. |
| 4.4 | Natural-prevalence evaluation | Probably yes | Reported held-out counts retain the cohort prevalences. |
| 4.5 | Partition separation | No information | Historical split/fitting objects are unavailable; prediction-set calibration dependencies are acknowledged. |
| 4.6 | Complete resampling procedures | No information | Full historical bootstrap/permutation execution records were not supplied. |
| 4.7 | Performance estimand suitability | Probably no | Unverified corrected-AUC intervals, sparse calibration support and incomplete learning/explanation diagnostics remain. |

## Domain and task interpretation

Development quality concerns: participants unclear; predictors unclear; outcome high for VISION and composites incorporating VISION, unclear for operative labels; analysis high. Evaluation risk: participants unclear; predictors unclear; outcome high for VISION/CURE and unclear for operative labels; analysis high. These judgments reflect the material available for this package and require assessor sign-off.

VISION has particularly limited event support and heterogeneous formal testing. CURE incorporates VISION and accepted neck-remnant adjudication; component mechanisms require separate interpretation. ACCESS and CONTROL use labels derived using full-cohort operative data; their prediction estimates are conditional on those labels. RECON describes an observed construct rather than anatomical necessity.

Overall development quality concern: **high**. Overall evaluation risk of bias: **high**. No developmental-phase label automatically determines this rating, and software tests do not lower it.

Applicability is assessed against an explicit purpose: research prediction in adults selected for ophthalmic-region clipping. For transfer to another institution, concern is high for participants/practice-related operative targets and unclear for predictor and endpoint compatibility. For immediate clinical decision use, concern is high. These statements do not assert that every single-center internal estimate is automatically biased because external validation is absent.

The revised reference code is evaluated by engineering tests separately. It cannot retroactively authenticate the historical analysis or supply missing clinical evidence.
