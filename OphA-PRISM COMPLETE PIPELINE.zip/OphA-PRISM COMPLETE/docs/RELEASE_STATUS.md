# Release status — 1.1.0

This is revised reference research software with author-reported aggregate resources. Folder layout, Python syntax, aggregate arithmetic, unit/integration checks and manifest integrity are tested as described in SOFTWARE_TEST_REPORT.md. The original flattened-archive recovery is documented.

The public 142-row availability table passes count and era reconciliation. Clinical measurement values, 408-variable master definitions, original v1.2.0 execution, historical model weights, per-patient predictions, complete learning/SHAP files, and signed administrative records have not been independently reproduced or authenticated. No full 2,000-bootstrap / 1,000-permutation clinical rerun was executed while creating this release.

Docker and R definitions are retained for inspection; any execution not listed in the test report remains untested. Clinical performance verification and external institutional evaluation remain separate from software verification.
