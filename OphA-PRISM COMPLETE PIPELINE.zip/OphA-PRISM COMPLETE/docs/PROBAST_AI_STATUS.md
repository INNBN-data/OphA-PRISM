# Assessment status

See [the structured 16+18-item appraisal](PROBAST_AI_34_questions.md). It uses official numbering and valid responses, with provisional judgments. It is not an independent signed assessment.
