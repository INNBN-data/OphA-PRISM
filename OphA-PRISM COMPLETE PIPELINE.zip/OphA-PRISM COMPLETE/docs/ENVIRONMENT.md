# Environment

The reference package supports Python 3.10–3.12 with the dependency ranges in requirements-core.txt and requirements-models.txt. Exact versions used for local checks are recorded in environment/tested_versions.json and SOFTWARE_TEST_REPORT.md. Earlier pinned definitions are retained under environment/original_* for provenance; they are not asserted to be the historical R environment.

The original R audit script remains under server_audit/. R MICE, pmsampsize and the historical execution environment require the institution's actual R package records. New Python posterior numeric imputations are not labelled an exact R MICE reproduction.
