# Reproducibility and provenance

Run `python run_pipeline.py check` for source/manifest checks and `python code/verify_aggregate_bundle.py` for public numerical relationships. Software test fixtures are artificial engineering inputs; none are clinical observations or estimated study performance.

To refit models, provide the genuine controlled data and input definitions, validate them, then run all configured folds. Every new fit records dataset/configuration/code hashes, training metadata, selected features, calibration roles, optimization histories, models and held-out predictions below `runs/private/`. Checkpoints reject incompatible versions. Collect only complete matching runs. Individual patient files and fitted models are never selected into the public release ZIP.

New execution of this reference workflow cannot establish that the historical model was locked before reserved-cohort access. The historical analysis requires its original dataset, ordered schemas, split IDs, fitted objects and execution records. Report new analyses as new versioned runs, and update manuscript values if the results change.

The `server_audit` component reads existing controlled artifacts and reports aggregate consistency. It does not recreate missing artifacts. The `outputs` public files retain author-supplied numbers with explicit provenance; arithmetic checks do not authenticate clinical measurements, adjudication, or historical executions.

Build the release after checks with `python scripts/build_release.py`. Packaging uses an explicit allowlist, records SHA-256 for every selected file and verifies ZIP integrity.
