# Software test report — 23 October 2026

**58 tests passed; 0 failures; 0 errors; 0 skipped.** Runtime: 4.964 seconds. Python 3.12.14. Exact package versions are in environment/tested_versions.json.

Tests cover endpoint consistency, missing outcomes, patient-group isolation, frozen preprocessing, structural codes, 20 imputations, different outer repeats, VISION identity calibration, model serialization, sparse-selection failure, integer-score aliases, BCa-vector checks, aggregate arithmetic, release policy and the server audit. All five task families completed a two-trial inner-tuning integration fixture. CatBoost, LightGBM and XGBoost optimization histories were exercised on nonclinical inputs. The integration check exposed and corrected CatBoost's None-valued best iteration during base refitting without a validation set.

The separate aggregate checker passes 1,113 relationships in the author-supplied tables. It does not independently verify clinical AUCs, calibration, BCa provenance or patient records. No full clinical nested-CV, bootstrap or permutation run was executed. Docker builds and the original R environment were not executed.

Command: `python -m unittest discover -s tests -v`. Machine summary: software_test_results.json. No clinical observations or empirical outputs were generated to make engineering tests pass.
