# TRIPOD+AI reporting map — 27 items

Numbering follows the 2024 checklist. Topics are abbreviated paraphrases. This map identifies provided material and reporting gaps; it is not a claim of complete compliance. Manuscript pagination must be filled against the final submitted PDF.

Source: Collins et al., BMJ 2024;385:e078378, https://doi.org/10.1136/bmj-2023-078378; official form: https://www.tripod-statement.org/wp-content/uploads/2019/12/TRIPODAI_checklist.pdf.

| Item | Topic | Location / status |
| --- | --- | --- |
| 1 | Title | Manuscript title; developmental wording requires final manuscript check. |
| 2 | Abstract | Manuscript abstract; low-event and validation limits should remain visible. |
| 3a–c | Background | Manuscript Introduction; sociodemographic inequalities are not fully reported. |
| 4 | Objectives | Manuscript Introduction; five outcomes and exploratory objectives. |
| 5a–b | Data sources/dates | STUDY_METADATA.md; chronology_and_accrual_ledger.md; source documents unverified. |
| 6a–c | Participants/treatment | Manuscript Methods; surgical pathway and eligibility. |
| 7 | Data preparation | METHODS.md; INPUT_CONTRACT.md; reference/historical distinctions. |
| 8a–c | Outcome assessment | ENDPOINTS.md; supplied component table; clinical adjudication remains controlled. |
| 9a–c | Predictor assessment | Public 142-row dictionary; operational definitions/category maps remain incomplete. |
| 10 | Sample size | Author-reported Riley scenario; original R output not supplied. |
| 11 | Missing data | 142-row era counts; explicit reference encoding; historical MICE differences documented. |
| 12a–g | Analytical procedures | METHODS.md and executable modules; historical artifacts remain unavailable. |
| 13 | Imbalance | Configured weighting and separate calibration; natural-prevalence evaluation. |
| 14 | Fairness | No complete subgroup fairness analysis supplied; not inferred from era tables. |
| 15 | Model output | Probabilities, binary prediction sets and developmental points; no validated treatment action. |
| 16 | Evaluation differences | Same-center temporal cohort and historical selection described. |
| 17 | Ethics | ETHICS_AND_CONTACTS.md; authorization assertions not authenticated. |
| 18a–f | Open science | README; disclosures; data access; internal protocol is not public registration. |
| 19 | Patient/public involvement | Not reported in supplied materials; no involvement is inferred. |
| 20a–c | Participant results | Manuscript cohort flow and aggregate tables; patient-level comparison unavailable. |
| 21 | Development support | Reported event counts; per-fit reference roles exported on execution. |
| 22 | Model specification | Reference code supplied; original fitted historical models not supplied. |
| 23a–b | Performance | Author aggregate tables; unverified interval provenance is explicit. |
| 24 | Updating | No post-lock updating is reported; historical evidence remains unavailable. |
| 25 | Interpretation | Manuscript Discussion; developmental scope. |
| 26 | Limitations | RELEASE_STATUS.md and manuscript limitations. |
| 27a–c | Usability/research | INPUT_CONTRACT.md; research workflow; independent evaluation still required. |
