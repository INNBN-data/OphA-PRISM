# Historical evidence and new-run exports

The public archive contains no fabricated execution records. A historical log should identify task, analytical variant, replicate kind/id, seed, completion status, runtime, statistic definition, source/config/code hashes, apparent AUC, original-sample test AUC and optimism. Failure records must be retained. Three thousand jobs means per task unless a job explicitly evaluates every task and exports separate results.

Held-out prediction files require patient ID, task, repeat, outer fold, observed outcome and probability; imputation members or pooled-imputation status must be specified. Each patient appears once per outer repeat. Probability calibration, conformal calibration and test membership must be linked to saved split IDs.

Full SHAP files need task/model, patient/fold provenance, feature order, output scale, reference background, explanation values and base values. ALE exports need numeric evaluation coordinates, bin definitions/counts, fitted response scale, uncertainty procedure and bootstrap provenance. A declared filename or schema is not an observed array.

The revised reference code records fitting.json, complete.json, predictions.csv and bundle.joblib within each private run. Historical cluster claims require historical records; new execution must use a new version/run ID.
