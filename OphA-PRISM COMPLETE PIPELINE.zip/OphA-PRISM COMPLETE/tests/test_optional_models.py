"""Optional small software checks, skipped when model dependencies are absent."""
import importlib.util
import unittest
import numpy as np
from ophaprism.training import fit_model


class OptionalModelInterfaceTests(unittest.TestCase):
    @unittest.skipUnless(all(importlib.util.find_spec(p) for p in ('optuna','lightgbm','catboost')),
                         'Optional learner/tuning dependencies are not installed')
    def test_all_five_task_families_complete_inner_tuning(self):
        import copy
        import pandas as pd
        from ophaprism.common import configuration
        from ophaprism.training import fit_pipeline
        rng=np.random.default_rng(77)
        x=pd.DataFrame({'measurement':rng.normal(size=120), 'second':rng.normal(size=120)})
        y=np.tile([0,1],60)
        cfg=configuration()
        cfg.update(imputation_backend='simple',imputations=1,optuna_trials=2,inner_folds=2)
        for task in ('VISION','ACCESS','CONTROL','RECON','CURE'):
            with self.subTest(task=task):
                spec=copy.deepcopy(cfg['models'][task]);spec['selection']={'enabled':False}
                if task=='ACCESS':spec['parameters']['iterations']=20
                if task=='CURE':spec['parameters']['n_estimators']=20
                bundle,metadata=fit_pipeline(x,y,np.arange(120),cfg,spec,42)
                self.assertEqual(len(metadata['optuna_trials']),2)
                self.assertTrue(np.isfinite(bundle.predict(x.iloc[:3])).all())

    def exercise(self, family, params):
        rng = np.random.default_rng(7)
        x = rng.normal(size=(80, 3))
        y = np.tile([0, 1], 40)
        fitted, history, rounds = fit_model(family, params, 42, x[:60], y[:60], (x[60:], y[60:]))
        self.assertTrue(history)
        self.assertTrue(np.isfinite(fitted.predict_proba(x[60:])[:, 1]).all())
        self.assertTrue(1 <= rounds <= 20)

    @unittest.skipUnless(importlib.util.find_spec("catboost"), "CatBoost is not installed locally")
    def test_catboost_inner_history(self):
        self.exercise("catboost", {"iterations": 20, "depth": 2, "learning_rate": .05})

    @unittest.skipUnless(importlib.util.find_spec("lightgbm"), "LightGBM is not installed locally")
    def test_lightgbm_inner_history(self):
        self.exercise("lightgbm", {"n_estimators": 20, "max_depth": 2, "num_leaves": 4, "learning_rate": .05})

    @unittest.skipUnless(importlib.util.find_spec("xgboost"), "XGBoost is not installed locally")
    def test_xgboost_inner_history(self):
        self.exercise("xgboost", {"n_estimators": 20, "max_depth": 2, "learning_rate": .05})
