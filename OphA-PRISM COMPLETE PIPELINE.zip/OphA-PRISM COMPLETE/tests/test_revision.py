"""Engineering checks for revision changes; fixtures are not clinical records."""
import importlib.util
import unittest
import copy
import numpy as np
import pandas as pd
from ophaprism.common import ROOT, configuration
from ophaprism.training import fit_pipeline
from ophaprism.preprocessing import canonical, processor, transform_frozen, imputed_partitions
from ophaprism.workflow import split_outer
from ophaprism.data import feature_spec, source_aliases
from ophaprism.bca import bca_interval


class RevisionTests(unittest.TestCase):
    def test_all_supplied_aggregate_relationships(self):
        spec=importlib.util.spec_from_file_location('aggregate_verify',ROOT/'code/verify_aggregate_bundle.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        result=module.verify(write=False)
        self.assertEqual(result['status'],'passed',result['failed'])

    def test_public_predictor_dictionary_works_without_invented_408_rows(self):
        import tempfile
        with tempfile.TemporaryDirectory() as directory:
            names=feature_spec(directory)
        self.assertEqual(len(names),142)
        self.assertIn('aneurysm_volume_mm3_derived',names)

    def test_structural_codes_are_distinct_from_unknown_and_valid_zero(self):
        raw=pd.DataFrame({'measurement':[0.,2.,-888.,-999.], 'category':['no','yes','-888','-999']})
        cooked=canonical(raw)
        self.assertEqual(cooked.measurement.iloc[0],0)
        self.assertEqual(cooked.measurement.iloc[2],0)
        self.assertEqual(cooked['__structural__measurement'].tolist(),[0,0,1,0])
        self.assertTrue(pd.isna(cooked.measurement.iloc[3]))
        self.assertEqual(cooked.category.iloc[2],'__STRUCTURAL_NA__')
        pd.testing.assert_frame_equal(cooked,canonical(cooked))
        pre=processor(raw,42,mode='simple').fit(raw)
        self.assertTrue(np.isfinite(transform_frozen(pre,raw)).all())

    def test_actual_outer_partitions_change_between_repeats(self):
        x=pd.DataFrame({'measurement':np.arange(60)})
        y=np.tile([0,1],30);groups=np.arange(60)
        cfg=configuration()
        first=split_outer(x,y,groups,cfg,0);second=split_outer(x,y,groups,cfg,1)
        self.assertFalse(all(np.array_equal(a[1],b[1]) for a,b in zip(first,second)))

    def test_vision_identity_calibration_and_private_roles(self):
        rng=np.random.default_rng(16)
        x=pd.DataFrame({'measurement':rng.normal(size=120)})
        y=np.tile([0,1],60)
        cfg=configuration();cfg.update(imputation_backend='simple',imputations=1,optuna_trials=1,inner_folds=2)
        spec=copy.deepcopy(cfg['models']['VISION']);spec['selection']={'enabled':False}
        bundle,metadata=fit_pipeline(x,y,np.arange(120),cfg,spec,42)
        self.assertEqual(bundle.calibration_method,'none')
        np.testing.assert_allclose(bundle.predict(x.iloc[:5]),bundle.raw_predict(x.iloc[:5]))
        memberships=[set(v) for v in metadata['role_patient_ids'].values()]
        self.assertTrue(all(not(a & b) for i,a in enumerate(memberships) for b in memberships[i+1:]))
        self.assertEqual(len(set.union(*memberships)),120)

    def test_imputation_ensemble_has_twenty_frozen_members(self):
        x=pd.DataFrame({'measurement':[.1,.5,.8,np.nan,1.2,1.6]})
        cfg=configuration()
        members=imputed_partitions(x,x.iloc[:2],cfg,4)
        self.assertEqual(len(members),20)
        for pre,_,held in members:
            np.testing.assert_allclose(held,transform_frozen(pre,x.iloc[:2]))

    def test_conflicting_aliases_are_rejected(self):
        from ophaprism.common import ValidationError
        with self.assertRaises(ValidationError):
            source_aliases(pd.DataFrame({'maximal_diameter_mm':[5.], 'max_diameter_mm':[7.]}))

    def test_integer_score_accepts_supplied_predictor_names(self):
        from ophaprism.scores import integers
        row=pd.DataFrame({'maximal_diameter_mm':[16.], 'neck_width_mm':[8.],
            'optic_nerve_compression':[1], 'opha_incorporated':[1],
            'neck_opha_involvement_percent':[25.], 'intraluminal_thrombus':[1]})
        self.assertEqual(integers(row,'VISION').tolist(),[31])

    def test_bca_rejects_non_estimable_acceleration(self):
        with self.assertRaises(ValueError):
            bca_interval(.5,np.linspace(0,1,40),np.ones(8))
        output=bca_interval(.5,np.linspace(.1,.9,200),np.linspace(.45,.55,30))
        self.assertLess(output['ci'][0],.5)
        self.assertGreater(output['ci'][1],.5)

if __name__=='__main__':
    unittest.main()
