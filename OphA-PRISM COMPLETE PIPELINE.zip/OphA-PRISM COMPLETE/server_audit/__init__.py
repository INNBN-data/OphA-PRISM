"""OphA-PRISM reference component."""
