#!/usr/bin/env python3
"""Verify supplied aggregate arithmetic without fitting models or inventing records."""
from pathlib import Path
import csv, json, math, sys

ROOT = Path(__file__).resolve().parents[1]

def read(name):
    with (ROOT/name).open(encoding="utf-8-sig",newline="") as f:
        return list(csv.DictReader(f))

def export(name, rows):
    with (ROOT/name).open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def verify(write=True):
    checks=[]
    def check(name, passed, detail=None):
        checks.append(dict(check=name,passed=bool(passed),detail=detail))
    dictionary=read("data/dictionary_142_era_stratified.csv")
    counts={layer:sum(r['layer']==layer for r in dictionary) for layer in ('T0','T1','T2')}
    check('142_unique_predictors',len(dictionary)==142==len({r['variable_name'] for r in dictionary}),counts)
    check('layer_counts',counts=={'T0':48,'T1':30,'T2':64})
    for r in dictionary:
        for e,n in [('E1',82),('E2',94),('E3',85)]:
            check(r['variable_name']+'_'+e,sum(int(r[e+'_'+c]) for c in ['obs','unk','inapp'])==n)
        for c in ['obs','unk','inapp']:
            check(r['variable_name']+'_total_'+c,sum(int(r[e+'_'+c]) for e in ['E1','E2','E3'])==int(r['Tot_'+c]))
        check(r['variable_name']+'_261',sum(int(r['Tot_'+c]) for c in ['obs','unk','inapp'])==261)
    byname={r['variable_name']:r for r in dictionary}
    core=['maximal_diameter_mm','neck_width_mm','optic_nerve_compression','opha_incorporated','intraluminal_thrombus']
    check('six_input_complete_case_arithmetic',all(int(byname[c]['Tot_obs'])==261 for c in core)
          and int(byname['neck_opha_involvement_percent']['Tot_obs'])==224
          and int(byname['neck_opha_involvement_percent']['Tot_unk'])==37)

    joint=read('outputs/cure_joint_distribution.csv')
    check('joint_total',sum(int(r['n']) for r in joint)==261)
    for component,expected in [('residual_sac',40),('opha_loss',2),('vision_event',23)]:
        check('joint_'+component,sum(int(r['n'])*int(r[component]) for r in joint)==expected)
    failure=sum(int(r['n']) for r in joint if any(int(r[c]) for c in ['residual_sac','opha_loss','vision_event']))
    tech=sum(int(r['n']) for r in joint if int(r['residual_sac'])==0 and int(r['opha_loss'])==0)
    check('CURE_union',failure==50);check('technical_success',tech==220)

    dca=[]
    for r in read('outputs/dca_data.csv'):
        t=float(r['threshold']);weight=t/(1-t)
        nb=(int(r['lightgbm_tp'])-int(r['lightgbm_fp'])*weight)/261
        rule=(int(r['rule_tp'])-int(r['rule_fp'])*weight)/261
        all_nb=(50-211*weight)/261
        for column,v in [('lightgbm_nb',nb),('rule_nb',rule),('act_on_all_nb',all_nb)]:
            check('DCA_'+column+'_'+str(t),abs(float(r[column])-v)<=.000051)
        dca.append(dict(threshold=t,lightgbm_nb=nb,rule_nb=rule,act_on_all_nb=all_nb,act_on_none_nb=0.0))

    prevalence={r['task']:int(r['events']) for r in read('outputs/task_performance_author_reported.csv')}
    phi=[]
    for r in read('outputs/phi_matrix.csv'):
        a=r['target'];na=prevalence[a]
        for b,nb in prevalence.items():
            joint_n=int(r['joint_'+b]);value=(261*joint_n-na*nb)/math.sqrt(na*(261-na)*nb*(261-nb))
            check('phi_'+a+'_'+b,abs(float(r[b])-value)<=.000501)
            phi.append(dict(first=a,second=b,joint_positive=joint_n,phi=value))

    skill=[]
    for r in read('outputs/task_performance_author_reported.csv'):
        p=int(r['events'])/261;bs=float(r['brier'])
        skill.append(dict(task=r['task'],prevalence=p,reference_brier=p*(1-p),brier=bs,brier_skill=1-bs/(p*(1-p))))
    for r in read('outputs/resampling_and_optimism_summary.csv'):
        check('optimism_subtraction_'+r['task'],abs(float(r['apparent_auc'])-float(r['mean_optimism'])-float(r['corrected_auc']))<1e-10)
        check('permutation_fraction_'+r['task'],abs(float(r['perm_p_value'])-(int(r['perm_exceedances'])+1)/1001)<1e-7)

    prediction=[]
    for task in ['VISION','CURE']:
        group=[r for r in read('outputs/prediction_set_counts.csv') if r['task']==task]
        for r in group:
            check('set_row_'+task+'_'+r['true_class'],int(r['n'])==sum(int(r[c]) for c in ['empty','singleton_0','singleton_1','both']))
        neg=next(r for r in group if r['true_class']=='0');pos=next(r for r in group if r['true_class']=='1')
        covered=int(neg['singleton_0'])+int(pos['singleton_1'])+int(neg['both'])+int(pos['both'])
        size=sum(int(r['singleton_0'])+int(r['singleton_1'])+2*int(r['both']) for r in group)/261
        ppv=int(pos['singleton_1'])/(int(pos['singleton_1'])+int(neg['singleton_1']))
        prediction.append(dict(task=task,n=261,covered=covered,coverage=covered/261,event_coverage=(int(pos['singleton_1'])+int(pos['both']))/int(pos['n']),positive_singleton_ppv=ppv,mean_set_size=size))
        check('mean_set_size_'+task,abs(size-264/261)<1e-12)

    changes=read('data/endpoint_reconciliation_case_level.csv');net_tech=0;net_cure=0
    for r in changes:
        for version in ['original','revised']:
            favorable=r[version+'_rroc'] in ['RROC I','RROC II (Accepted)']
            technical=favorable and r[version+'_opha']=='Patent'
            cure=not technical or r['vision_event']=='Yes'
            check(r['reconciliation_id']+'_'+version+'_technical',technical==(r[version+'_tech_success']=='Yes'))
            check(r['reconciliation_id']+'_'+version+'_cure',cure==(r[version+'_cure_failure']=='Yes'))
        net_tech+=(r['revised_tech_success']=='Yes')-(r['original_tech_success']=='Yes')
        net_cure+=(r['revised_cure_failure']=='Yes')-(r['original_cure_failure']=='Yes')
    check('reconciliation_net_technical',net_tech==2);check('reconciliation_net_CURE',net_cure==0)
    fig=json.loads((ROOT/'outputs/complete_figure_source_data.json').read_text())
    ale=fig['ale_cure_diameter']
    check('ALE_bin_count_total',sum(ale['patient_counts'])==261)
    check('ALE_large_bin_count',sum(ale['patient_counts'][-4:])==42)
    check('ALE_interval_order',all(lo<=v<=hi for lo,v,hi in zip(ale['ci_lower_95'],ale['ale_values'],ale['ci_upper_95'])))
    report={'status':'passed' if all(r['passed'] for r in checks) else 'failed',
        'checks':len(checks),'failed':[r for r in checks if not r['passed']],
        'scope':'Arithmetic of author-reported aggregates; no clinical fitting or source authentication.',
        'historical_clinical_results_reproduced':False,'predictor_counts':counts,
        'unverified':['clinical source records','AUC and calibration estimates','resampling execution and BCa intervals','SHAP values and ALE bootstrap provenance','historical dataset/model lock dates']}
    if write:
        (ROOT/'outputs/aggregate_verification.json').write_text(json.dumps(report,indent=2)+'\n')
        export('outputs/arithmetic_dca.csv',dca);export('outputs/arithmetic_phi.csv',phi)
        export('outputs/arithmetic_brier_skill.csv',skill);export('outputs/arithmetic_prediction_sets.csv',prediction)
    return report

if __name__=='__main__':
    report=verify();print(json.dumps(report,indent=2));sys.exit(0 if report['status']=='passed' else 1)
