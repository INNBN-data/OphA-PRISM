"""Run the revised package CLI with strict per-partition fitting.

Example: python code/nested_cv_strict_isolation.py train --task VISION
         --data-root /controlled/study-data --run reference_110 --repeat 0 --fold 0
This is reference version 1.1.0, not the executed historical v1.2.0 workflow.
"""
from pathlib import Path
import runpy
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
runpy.run_path(str(Path(__file__).resolve().parents[1] / "run_pipeline.py"), run_name="__main__")
