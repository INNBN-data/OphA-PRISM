# OphA-PRISM — revised reference pipeline and aggregate bundle

**Version 1.1.0 

## Included

- Five task-specific learners; repeated 5-fold outer evaluation, 4-fold inner tuning, training-only preprocessing and feature selection.
- Twenty posterior numeric imputations; categorical mode imputation/encoding; per-patient prediction averaging. This Python backend differs from historical R MICE.
- Separate probability and prediction-set calibration partitions. VISION uses raw probabilities by default because of sparse calibration events.
- Bootstrap optimism, outcome permutations, LOEO and rolling-origin commands; empirical diagnostics, score calculation, and controlled-server auditing.
- Exactly 142 author-supplied predictor rows: 48 T0, 30 T1 and 64 T2. All reported availability rows reconcile to era sizes 82/94/85.
- Author-reported aggregate performance, CURE overlap, DCA counts, prediction sets, SHAP summaries, ALE coordinates, and selected learning snapshots.
- Reporting checklists, provenance/status records, numerical verification, software tests, and checksum-based packaging.

## Start

Use Python 3.10 or newer. For the originally pinned dependency environment use the supplied Docker/environment definitions. The actual local test environment is recorded in `docs/SOFTWARE_TEST_REPORT.md`.

```bash
python -m pip install -r requirements.txt
python run_pipeline.py --help
python run_pipeline.py check
python code/verify_aggregate_bundle.py
python -m unittest discover -s tests -v
```

Training requires the institution's genuine patient-level data. No clinical observations, fitted clinical model, historical OOF predictions, or full execution/SHAP arrays were included in the uploaded archive. `outputs/artifact_inventory.json` records those boundaries. The software fails when required clinical inputs are absent.

```bash
python run_pipeline.py validate --data-root /controlled/study-data
python run_pipeline.py train --data-root /controlled/study-data --task VISION --run reference_110 --repeat 0 --fold 0
# Run every repeat 0..9 and fold 0..4 before collecting.
python run_pipeline.py collect --task VISION --run reference_110
```

See `docs/INPUT_CONTRACT.md`, `docs/METHODS.md`, and `docs/REPRODUCIBILITY.md`. Generated individual records remain below `runs/private/`; they are excluded from public packaging. The original 408-variable master dictionary is not fabricated from the 142 supplied predictors.

## Evidence and interpretation

`outputs/` contains **author-reported aggregates**, except files explicitly marked as arithmetic recomputations. `python code/verify_aggregate_bundle.py` checks their internal numerical relationships; it does not refit a clinical model or authenticate the clinical source records. The revised reference workflow is not expected to reproduce historical values merely because its configuration resembles the manuscript.

