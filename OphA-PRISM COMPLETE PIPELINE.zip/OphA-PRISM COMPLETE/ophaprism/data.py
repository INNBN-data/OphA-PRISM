from __future__ import annotations
from pathlib import Path
import re
import numpy as np
import pandas as pd
from .common import ROOT, ValidationError, configuration, read_csv, identifiers, require_columns
from .endpoints import validate_and_add, LABELS

FORBIDDEN = set(LABELS.values()) | {
    "patient_id", "lesion_id", "op_id", "cohort_flag", "surgery_year", "era", "surgeon_id",
    "technical_success", "rroc_grade", "opha_patency_loss", "remnant_intentional_stable",
    "followup_days", "vision_6mo_confirmed", "outcome_missing_flag", "angiography_days",
    "angiography_modality", "clinician_rating", "mean_clinician_rating"}


def file_under(root, relative):
    root = Path(root).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValidationError("input_path_escapes_data_root")
    if not path.is_file():
        raise ValidationError("required_server_input_missing: " + relative)
    return path


def feature_spec(root, cfg=None):
    cfg = cfg or configuration()
    feature_path = Path(root) / cfg["paths"]["eligible_features"]
    if not feature_path.is_file() and cfg.get("allow_public_predictor_schema", False):
        feature_path = ROOT / "data/eligible_t0_t2_features.txt"
    else:
        feature_path = file_under(root, cfg["paths"]["eligible_features"])
    names = [x.strip() for x in feature_path.read_text(encoding="utf-8-sig").splitlines()
             if x.strip() and not x.lstrip().startswith("#")]
    if len(names) != 142 or len(set(names)) != 142:
        raise ValidationError("actual_142_unique_eligible_feature_names_required")
    if set(names) & FORBIDDEN:
        raise ValidationError("outcome_identifier_era_or_operator_in_predictor_list")
    dictionary_path = Path(root) / cfg["paths"]["dictionary"]
    if not dictionary_path.is_file() and cfg.get("allow_public_predictor_schema", False):
        dictionary_path = ROOT / "data/predictor_dictionary_142.csv"
    else:
        dictionary_path = file_under(root, cfg["paths"]["dictionary"])
    dictionary = read_csv(dictionary_path)
    m = cfg["dictionary_columns"]
    require_columns(dictionary, list(m.values()))
    if len(dictionary) not in (142, 408) or dictionary[m["name"]].nunique() != len(dictionary):
        raise ValidationError("unique_142_predictor_or_complete_408_variable_dictionary_required")
    flags = dictionary[m["eligible"]].astype(str).str.lower().map(
        {"true": True, "false": False, "1": True, "0": False, "1.0": True, "0.0": False})
    if flags.isna().any():
        raise ValidationError("dictionary_eligibility_must_be_boolean")
    layers = dictionary[m["layer"]].astype(str).str.extract(r"^(T[0-7])(?:\b|$)")[0]
    if layers.isna().any() or (flags & ~layers.isin(["T0", "T1", "T2"])).any():
        raise ValidationError("invalid_temporal_eligibility")
    eligible = dictionary.loc[flags, m["name"]].astype(str)
    if set(eligible) != set(names):
        raise ValidationError("dictionary_and_feature_list_disagree")
    return names


def source_aliases(data):
    """Expose documented legacy measurement names without altering the predictor list."""
    aliases = {"maximal_diameter_mm": "max_diameter_mm", "aneurysm_height_mm": "height_mm",
        "dome_to_neck_ratio_derived": "dome_to_neck_ratio", "aspect_ratio_derived": "aspect_ratio",
        "opha_incorporated": "opha_incorporation", "neck_opha_involvement_percent": "neck_opha_involvement_pct",
        "optic_nerve_compression": "optic_compression", "visual_symptoms_preop": "preoperative_visual_symptoms"}
    data = data.copy()
    for source, legacy in aliases.items():
        if source not in data:
            continue
        if legacy in data:
            both = data[source].notna() & data[legacy].notna()
            if not data.loc[both, source].eq(data.loc[both, legacy]).all():
                raise ValidationError("conflicting_source_and_legacy_measurement_names")
        else:
            data[legacy] = data[source]
    return data


def load_cohort(root, cohort="development", cfg=None, include_features=True):
    cfg = cfg or configuration()
    source = file_under(root, cfg["paths"][cohort])
    data = source_aliases(read_csv(source))
    identifiers(data)
    if len(data) != (261 if cohort == "development" else 28):
        raise ValidationError("cohort_size_disagrees_with_fixed_study_definition")
    require_columns(data, ["cohort_flag", "surgery_year", "era"])
    expected_flag = 0 if cohort == "development" else 1
    if data.cohort_flag.isna().any() or not data.cohort_flag.eq(expected_flag).all():
        raise ValidationError("wrong_or_missing_cohort_flag")
    year = pd.to_numeric(data.surgery_year, errors="raise")
    if cohort == "development":
        assigned = pd.Series(np.nan, index=data.index)
        for era, low, high in cfg["eras"]:
            assigned.loc[year.between(low, high)] = era
        if assigned.isna().any() or not assigned.eq(pd.to_numeric(data.era, errors="raise")).all():
            raise ValidationError("era_and_year_disagree")
    elif not year.eq(2026).all():
        raise ValidationError("holdout_year_does_not_match_reported_cohort")
    if "surgery_date" in data:
        dates = pd.to_datetime(data.surgery_date, errors="coerce")
        low, high = ("1998-01-01", "2025-07-18") if cohort == "development" else ("2026-01-01", "2026-03-31")
        if dates.isna().any() or not dates.between(low, high).all() or not dates.dt.year.eq(year).all():
            raise ValidationError("surgery_dates_disagree_with_cohort_chronology")
    data = validate_and_add(data)
    if include_features:
        features = feature_spec(root, cfg)
        require_columns(data, features)
    return data.reset_index(drop=True), source


def validate_inputs(root, include_holdout=False):
    cfg = configuration()
    features = feature_spec(root, cfg)
    development, source = load_cohort(root, cfg=cfg)
    if len(development) != 261:
        raise ValidationError("development_count_disagrees_with_reported_261")
    result = {"development_n": len(development), "eligible_features": len(features),
              "dictionary_scope": "142-predictor schema or supplied 408-variable master",
              "exact_operation_cutoff_checked": "surgery_date" in development,
              "source_hash_required_at_run": True}
    if include_holdout:
        holdout, _ = load_cohort(root, "holdout", cfg)
        if len(holdout) != 28 or set(holdout.patient_id) & set(development.patient_id):
            raise ValidationError("holdout_count_or_patient_independence_error")
        result["holdout_n"] = len(holdout)
    return result
