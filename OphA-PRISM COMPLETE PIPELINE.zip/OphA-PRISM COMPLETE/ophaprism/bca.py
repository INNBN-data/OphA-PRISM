"""BCa intervals from explicitly supplied estimates of one declared statistic.

This utility does not manufacture corrected-AUC replicates from optimism values.
"""
from __future__ import annotations
import numpy as np
from scipy.stats import norm


def bca_interval(observed, bootstrap_estimates, jackknife_estimates, confidence=.95):
    boot = np.asarray(bootstrap_estimates, float)
    jack = np.asarray(jackknife_estimates, float)
    if (boot.ndim != 1 or jack.ndim != 1 or len(boot) < 20 or len(jack) < 3
            or not np.isfinite(boot).all() or not np.isfinite(jack).all()
            or not np.isfinite(observed) or not 0 < confidence < 1):
        raise ValueError("finite_matching_statistic_vectors_required")
    fraction = float(np.mean(boot < observed))
    if not 0 < fraction < 1:
        raise ValueError("BCa_bias_correction_is_infinite")
    influence = jack.mean() - jack
    square = float(np.sum(influence ** 2))
    if square <= 0:
        raise ValueError("BCa_acceleration_not_estimable")
    acceleration = float(np.sum(influence ** 3) / (6 * square ** 1.5))
    z0 = float(norm.ppf(fraction))
    tail = (1 - confidence) / 2
    z = norm.ppf([tail, 1-tail])
    denominator = 1 - acceleration * (z0 + z)
    if np.any(denominator <= 0):
        raise ValueError("BCa_adjusted_tail_singularity")
    adjusted = norm.cdf(z0 + (z0 + z) / denominator)
    if not adjusted[0] < adjusted[1]:
        raise ValueError("BCa_adjusted_tails_not_ordered")
    interval = np.quantile(boot, adjusted)
    return {"estimate":float(observed), "ci":interval.tolist(), "confidence":confidence,
            "bias_correction_z0":z0, "acceleration":acceleration,
            "adjusted_quantiles":adjusted.tolist(), "bootstrap_replicates":len(boot),
            "jackknife_observations":len(jack),
            "scope":"Input vectors must target the same estimator; no model fitting is implied."}
