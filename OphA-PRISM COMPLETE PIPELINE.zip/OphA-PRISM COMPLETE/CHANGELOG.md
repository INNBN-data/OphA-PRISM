# Changelog

## 1.1.0 — 23 October 2026

- Restored package directories from the flattened input ZIP and recorded source recovery.
- Integrated the latest 142-row availability table, input schema and ordered feature list.
- Added supplied endpoint reconciliation and aggregate performance/DCA/phi/prediction-set/explanation resources.
- Preserved all original analysis components and added aggregate verification and BCa-vector utilities.
- Added VISION raw-probability mode, patient-role exports, structural-code handling and source-name aliases.
- Updated chronology, disclosure/provenance documentation and correctly structured reporting assessments.
- Recorded new software checks separately from unverified historical clinical outputs.

## 1.0.1

Original reference implementation identified in the supplied archive.
